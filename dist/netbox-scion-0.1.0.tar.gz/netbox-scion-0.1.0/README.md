# NetBox SCION Plugin

A NetBox plugin for managing SCION Links Assignment, Organizations, and ISD-ASes (Isolation Domain - Autonomous Systems).

## Features

- **Organizations**: Manage organizations that operate ISD-ASes
- **ISD-ASes**: Track SCION ISD-AS identifiers with their organizations and core nodes
- **SCION Link Assignments**: Manage interface assignments to customers with Zendesk ticket tracking
- **Full REST API**: Complete CRUD operations via REST API
- **Export Support**: Export data to Excel/CSV format
- **Advanced Filtering**: Filter link assignments by customer information
- **Audit Logging**: Track all changes with NetBox's built-in change logging

## Models

### Organization
- `short_name`: Unique short name for the organization
- `full_name`: Full organization name
- `description`: Optional description

### ISDAS (ISD-AS)
- `isd_as`: Unique identifier in format `{isd}-{as}` (e.g., `1-ff00:0:110`)
- `organization`: Reference to the operating organization
- `cores`: List of core nodes (PostgreSQL ArrayField or JSON)
- `description`: Optional description

### SCIONLinkAssignment
- `isd_as`: Reference to the ISD-AS
- `interface_id`: Interface ID (unique per ISD-AS)
- `customer_id`: Customer identifier
- `customer_name`: Customer name
- `zendesk_ticket`: Zendesk ticket number (with automatic URL generation)

## Installation

1. Install the plugin:
```bash
pip install netbox-scion
```

2. Add to NetBox's `PLUGINS` configuration in `configuration.py`:
```python
PLUGINS = [
    'netbox_scion',
]
```

3. Run migrations:
```bash
python manage.py migrate
```

4. Restart NetBox:
```bash
sudo systemctl restart netbox
```

## Configuration

No additional configuration is required. The plugin works out-of-the-box with NetBox's default settings.

## Usage

### Web Interface
- Navigate to "SCION" in the NetBox menu
- Access Organizations, ISD-ASes, and Link Assignments
- Use the filtering capabilities for SCION Link Assignments

### REST API
The plugin provides full REST API access:

- Organizations: `/api/plugins/scion/organizations/`
- ISD-ASes: `/api/plugins/scion/isd-ases/`
- Link Assignments: `/api/plugins/scion/link-assignments/`

### Export
All models support export to Excel/CSV format through the web interface.

## API Examples

### Create an Organization
```bash
curl -X POST http://netbox.example.com/api/plugins/scion/organizations/ 
  -H "Authorization: Token YOUR_TOKEN" 
  -H "Content-Type: application/json" 
  -d '{
    "short_name": "ACME",
    "full_name": "ACME Corporation",
    "description": "Sample organization"
  }'
```

### Create an ISD-AS
```bash
curl -X POST http://netbox.example.com/api/plugins/scion/isd-ases/ 
  -H "Authorization: Token YOUR_TOKEN" 
  -H "Content-Type: application/json" 
  -d '{
    "isd_as": "1-ff00:0:110",
    "organization": 1,
    "cores": ["core1.example.com", "core2.example.com"],
    "description": "Sample ISD-AS"
  }'
```

### Create a Link Assignment
```bash
curl -X POST http://netbox.example.com/api/plugins/scion/link-assignments/ 
  -H "Authorization: Token YOUR_TOKEN" 
  -H "Content-Type: application/json" 
  -d '{
    "isd_as_id": 1,
    "interface_id": 1,
    "customer_id": "CUST001",
    "customer_name": "Customer Corp",
    "zendesk_ticket": "12345"
  }'
```

## Development

### Setting up for Development

1. Clone the repository:
```bash
git clone https://github.com/aciupac/netbox-scion.git
cd netbox-scion
```

2. Install in development mode:
```bash
pip install -e .
```

3. Run tests:
```bash
python manage.py test netbox_scion
```

## Requirements

- NetBox 3.5+
- Python 3.8+
- Django 4.0+

## License

This project is licensed under the Apache License 2.0.

## Support

For issues and feature requests, please use the GitHub issue tracker.
